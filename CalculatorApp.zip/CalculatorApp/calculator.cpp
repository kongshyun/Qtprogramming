#include "calculator.h"

Calculator::Calculator(double num1, char op, double num2)         // 생성자
    : num1(num1), num2(num2), op(op)
{

}
